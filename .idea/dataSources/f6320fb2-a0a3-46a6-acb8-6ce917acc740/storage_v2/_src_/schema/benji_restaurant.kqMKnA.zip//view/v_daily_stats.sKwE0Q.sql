create definer = root@localhost view v_daily_stats as
select `benji_restaurant`.`bjr_views_stats`.`item_id`                 AS `item_id`,
       cast(`benji_restaurant`.`bjr_views_stats`.`view_date` as date) AS `day`,
       count(0)                                                       AS `views`
from `benji_restaurant`.`bjr_views_stats`
group by `benji_restaurant`.`bjr_views_stats`.`item_id`, cast(`benji_restaurant`.`bjr_views_stats`.`view_date` as date);

