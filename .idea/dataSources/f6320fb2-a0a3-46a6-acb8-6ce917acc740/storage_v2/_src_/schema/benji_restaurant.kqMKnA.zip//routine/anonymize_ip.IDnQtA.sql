create
    definer = root@localhost function anonymize_ip(ip varchar(45)) returns varchar(45) deterministic
BEGIN
    -- Anonymise IPv4 (192.168.1.123 → 192.168.1.0)
    IF ip LIKE '%.%' THEN
        RETURN CONCAT(SUBSTRING_INDEX(ip, '.', 3), '.0');
        -- Anonymise IPv6 (simplifiée)
    ELSEIF ip LIKE '%:%' THEN
        RETURN CONCAT(SUBSTRING_INDEX(ip, ':', 3), '::0');
    ELSE
        RETURN '0.0.0.0';
    END IF;
END;

