create
    definer = root@localhost procedure save_view(IN p_item_id int, IN p_ip varchar(45), IN p_user_agent text,
                                                 IN p_referrer varchar(512))
BEGIN
    -- Enregistrement détaillé
    INSERT INTO bjr_views_stats (item_id, view_date, ip_address, user_agent, referrer)
    VALUES (p_item_id, NOW(), anonymize_ip(p_ip), p_user_agent, p_referrer);

    -- Mise à jour des stats agrégées (optionnel)
    INSERT INTO bjr_merge_stats (item_id, daily_date, views)
    VALUES (p_item_id, CURDATE(), 1)
    ON DUPLICATE KEY UPDATE views = views + 1;
END;

